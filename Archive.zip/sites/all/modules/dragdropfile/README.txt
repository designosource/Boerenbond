Thanks to http://drupal.org/sandbox/z7/1348240 for the 'multiple' part.
